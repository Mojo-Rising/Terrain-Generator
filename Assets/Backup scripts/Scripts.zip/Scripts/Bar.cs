﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bar : MonoBehaviour {

    // Use this for initialization
    public GameObject go;

    int count = 1;
	void Start () {
        Terrain t = Instantiate(go).GetComponent<Terrain>();
        TerrainData td = new TerrainData();
        td.size = new Vector3(2000, 400, 2000);
        td.heightmapResolution = 2049;
        t.terrainData = td;


        Tile tile = Tile.LoadTile(Application.dataPath + "/output/" + "Tile" + 72 + ".dat");
        count++;
        t.terrainData.SetHeights(0, 0, tile.GetHeightMap(0, 200));
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
