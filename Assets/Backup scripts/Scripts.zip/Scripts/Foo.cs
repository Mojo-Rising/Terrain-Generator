﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Foo : MonoBehaviour {
    public KeyCode PressToLoad;
    public string Name;
    Terrain MyTerrain;
    Tile MyTile;
    float[,] heights;

    private void Start()
    {
        MyTerrain = GetComponent<Terrain>();
    }

    private void Update()
    {
        if (Input.GetKeyUp(PressToLoad))
        {
            MyTile = Tile.LoadTile(Application.dataPath + "/output/" + Name + ".dat");
            heights = new float[MyTile.SizeX, MyTile.SizeY];
            heights = MyTile.GetHeightMap(0, 200);
            MyTerrain.terrainData.SetHeights(0, 0, heights);
            Debug.Log("length x: " + heights.GetLength(0) + ", length y: " + heights.GetLength(1));
        }
    }
}