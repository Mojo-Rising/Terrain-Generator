﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapGenerator : MonoBehaviour {

	public int mapWidth;
	public int mapHeight;
	public float noiseScale;

	public bool autoUpdate;

    public int divider = 16;
    public bool sliceTile;

    public float meshHeightMultiplier = 200;

    public enum DrawMode {HeightMap, Mesh};
    public DrawMode drawMode;


    public void GenerateMap() {
        //float[,] noiseMap = Noise.GenerateNoiseMap (mapWidth, mapHeight, noiseScale);

        Tile MyTile = Tile.LoadTile(Application.dataPath + "/output/Tile82.dat");

        float[,] noiseMap = new float[MyTile.SizeX, MyTile.SizeY];
        noiseMap = MyTile.GetHeightMap(0, 200);

        MapDisplay display = FindObjectOfType<MapDisplay> ();
        display.tileCount = 0;

        if (sliceTile)
        {
            List<TileSlice> slicedChunks = new List<TileSlice>();
            slicedChunks = TileSlice.GetSlicedHeightMap(divider, noiseMap);

            foreach (TileSlice thisSlice in slicedChunks)
            {
                Vector3 position = new Vector3(thisSlice.sliceX, 0, thisSlice.sliceY);

                if (drawMode == DrawMode.Mesh)
                {
                    display.DrawMesh(MeshGenerator.GenerateTerrainMesh(thisSlice.sliceHeightMap, meshHeightMultiplier), position);
                }
                else if (drawMode == DrawMode.HeightMap)
                {
                    display.DrawNoiseMap(thisSlice.sliceHeightMap, position);
                }
            }
        } else
        {
            display.DrawNoiseMap(noiseMap, Vector3.zero);
        }

        

        

    }
	
}
